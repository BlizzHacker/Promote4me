=== Promote4.me Proof Manager ===
Contributors: promote4me
Tags: proof, delivery, field service, orders, gps
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 2.9.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Create proof-ready work packets from supported store orders with staffer checklists, GPS/photo evidence, and approval tracking.

== Description ==
Promote4.me Proof Manager connects WordPress store activity to Promote4.me work packets. It helps teams dispatch delivery, field service, and proof-of-work tasks from store orders.

== Installation ==
1. Upload the plugin ZIP in Plugins > Add New > Upload Plugin.
2. Activate Promote4.me Proof Manager.
3. Go to Promote4.me > Settings.
4. Paste your Promote4.me External API Key.
5. Open Promote4.me > Dashboard and send a test work packet.

== Changelog ==
= 2.9.5 =
* Renamed for WordPress.org trademark compliance.
* Added dashboard, logs, hot keys, test packet, settings, proof checklist payloads, and order sync support.
